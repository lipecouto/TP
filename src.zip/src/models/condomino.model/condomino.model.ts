export class Condomino {

    constructor(public codigo: number,
                public nome: string,
                public cpf: string,
                public nascimento: string,
                public email: string,
                public endereco: string,
                public telefone: string,
                public qtdade_pessoas: number,
                public tempo_permanencia: number,
                public apto:number) { }
}